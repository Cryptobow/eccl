<?php

namespace Vinelab\Minion;

use Exception;

/**
 * @author Abed Halawi <abed.halawi@vinelab.com>
 */
class InvalidProviderException extends Exception
{
}
